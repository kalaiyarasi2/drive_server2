import { useState, useCallback } from "react";
import { FileUploadZone } from "@/components/FileUploadZone";
import { ProcessingSteps } from "@/components/ProcessingSteps";
import { CompletionDialog } from "@/components/CompletionDialog";
import { extractInvoice, type ExtractionResult } from "@/lib/api";
import { toast } from "sonner";

type AppState = "upload" | "processing" | "done";

const Index = () => {
  const [state, setState] = useState<AppState>("upload");
  const [step, setStep] = useState(-1);
  const [result, setResult] = useState<ExtractionResult | null>(null);
  const [filename, setFilename] = useState("");

  const simulateSteps = useCallback(
    async (file: File) => {
      setState("processing");
      setFilename(file.name);

      // Step 0: Uploading
      setStep(0);
      await new Promise((r) => setTimeout(r, 800));

      // Step 1: Analyzing
      setStep(1);

      try {
        // Start the actual API call during "Analyzing"
        const promise = extractInvoice(file);

        await new Promise((r) => setTimeout(r, 1200));

        // Step 2: Extracting
        setStep(2);

        const data = await promise;

        await new Promise((r) => setTimeout(r, 800));

        // Step 3: Complete
        setStep(3);
        await new Promise((r) => setTimeout(r, 600));

        setResult(data);
        setState("done");
      } catch (err: any) {
        toast.error(err.message || "Something went wrong");
        reset();
      }
    },
    []
  );

  const reset = useCallback(() => {
    setState("upload");
    setStep(-1);
    setResult(null);
    setFilename("");
  }, []);

  return (
    <div className="relative min-h-screen grid-bg flex flex-col items-center justify-center px-4 py-12">
      {/* Ambient glow */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute left-1/2 top-0 -translate-x-1/2 h-[500px] w-[800px] rounded-full bg-primary/5 blur-[120px]" />
      </div>

      {/* Title */}
      <h1 className="relative mb-2 text-4xl sm:text-5xl font-extrabold tracking-tight text-foreground neon-text">
        PDF Invoice Extractor
      </h1>
      <p className="relative mb-10 text-muted-foreground text-lg">
        Upload a PDF invoice and extract structured data instantly
      </p>

      {/* Main Content */}
      <div className="relative w-full max-w-xl transition-all duration-500">
        {state === "upload" && (
          <div className="animate-fade-in">
            <FileUploadZone onExtract={simulateSteps} />
          </div>
        )}

        {state === "processing" && (
          <div className="animate-fade-in">
            <ProcessingSteps currentStep={step} />
          </div>
        )}
      </div>

      {/* Completion Dialog */}
      <CompletionDialog
        open={state === "done"}
        result={result}
        filename={filename}
        onClose={reset}
        onReset={reset}
      />
    </div>
  );
};

export default Index;
