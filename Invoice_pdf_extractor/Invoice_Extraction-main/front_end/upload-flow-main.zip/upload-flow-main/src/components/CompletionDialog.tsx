import { CheckCircle2, Download, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { getDownloadUrl, type ExtractionResult } from "@/lib/api";

interface CompletionDialogProps {
  open: boolean;
  result: ExtractionResult | null;
  filename: string;
  onClose: () => void;
  onReset: () => void;
}

export function CompletionDialog({
  open,
  result,
  filename,
  onClose,
  onReset,
}: CompletionDialogProps) {
  if (!result) return null;

  const previewRows = (result.preview_data || []).slice(0, 5);
  const columns = previewRows.length
      ? Object.keys(previewRows[0])
      : [];

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="glass-card border-border sm:max-w-2xl max-h-[85vh] overflow-y-auto">
        <DialogHeader className="items-center text-center">
          <div className="mx-auto mb-3 flex h-16 w-16 items-center justify-center rounded-full bg-[hsl(var(--success)/0.15)] success-glow">
            <CheckCircle2 className="h-8 w-8 text-[hsl(var(--success))]" />
          </div>
          <DialogTitle className="text-xl text-foreground">
            Extraction Complete!
          </DialogTitle>
          <DialogDescription className="text-muted-foreground">
            <span className="font-medium text-foreground">{filename}</span> —{" "}
            {result.row_count} rows extracted
          </DialogDescription>
        </DialogHeader>

        {/* Preview Table */}
        {previewRows.length > 0 && (
          <div className="mt-4 rounded-lg border border-border overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow className="border-border bg-muted/30">
                  {columns.map((col) => (
                    <TableHead
                      key={col}
                      className="text-primary font-semibold whitespace-nowrap"
                    >
                      {col}
                    </TableHead>
                  ))}
                </TableRow>
              </TableHeader>
              <TableBody>
                {previewRows.map((row, i) => (
                  <TableRow key={i} className="border-border">
                    {columns.map((col) => (
                      <TableCell key={col} className="whitespace-nowrap">
                        {row[col] ?? "—"}
                      </TableCell>
                    ))}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}

        {/* Actions */}
        <div className="mt-4 flex flex-col sm:flex-row gap-3">
          <Button
            asChild
            className="flex-1 bg-primary text-primary-foreground hover:bg-primary/80 neon-border font-semibold"
          >
            <a href={getDownloadUrl(result.output_file)} download>
              <Download className="mr-2 h-4 w-4" />
              Download Excel
            </a>
          </Button>
          <Button
            variant="outline"
            className="flex-1 border-border text-foreground hover:bg-muted"
            onClick={onReset}
          >
            <RotateCcw className="mr-2 h-4 w-4" />
            Extract Another
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
