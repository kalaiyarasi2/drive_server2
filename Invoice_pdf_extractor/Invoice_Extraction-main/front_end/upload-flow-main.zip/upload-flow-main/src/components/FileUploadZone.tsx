import { useCallback, useState } from "react";
import { Upload, FileText, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

interface FileUploadZoneProps {
  onExtract: (file: File) => void;
  disabled?: boolean;
}

export function FileUploadZone({ onExtract, disabled }: FileUploadZoneProps) {
  const [file, setFile] = useState<File | null>(null);
  const [dragOver, setDragOver] = useState(false);

  const handleFile = useCallback((f: File) => {
    if (f.type !== "application/pdf") {
      toast.error("Only PDF files are supported");
      return;
    }
    setFile(f);
  }, []);

  const onDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setDragOver(false);
      if (e.dataTransfer.files[0]) handleFile(e.dataTransfer.files[0]);
    },
    [handleFile]
  );

  const onFileInput = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      if (e.target.files?.[0]) handleFile(e.target.files[0]);
    },
    [handleFile]
  );

  return (
    <div className="flex flex-col items-center gap-6 w-full max-w-xl mx-auto">
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setDragOver(true);
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={onDrop}
        className={`relative w-full rounded-xl border-2 border-dashed p-10 text-center transition-all duration-300 cursor-pointer glass-card ${
          dragOver
            ? "border-primary neon-border scale-[1.02]"
            : file
              ? "border-primary/50"
              : "border-border pulse-border"
        }`}
        onClick={() => document.getElementById("pdf-input")?.click()}
      >
        <input
          id="pdf-input"
          type="file"
          accept=".pdf,application/pdf"
          className="hidden"
          onChange={onFileInput}
          disabled={disabled}
        />

        {file ? (
          <div className="flex flex-col items-center gap-3">
            <div className="relative">
              <FileText className="h-14 w-14 text-primary" />
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setFile(null);
                }}
                className="absolute -top-2 -right-2 rounded-full bg-destructive p-1 text-destructive-foreground hover:scale-110 transition-transform"
              >
                <X className="h-3 w-3" />
              </button>
            </div>
            <p className="text-foreground font-medium">{file.name}</p>
            <p className="text-muted-foreground text-sm">
              {(file.size / 1024 / 1024).toFixed(2)} MB
            </p>
          </div>
        ) : (
          <div className="flex flex-col items-center gap-3">
            <Upload className="h-14 w-14 text-muted-foreground" />
            <p className="text-foreground font-medium">
              Drag & drop your PDF here
            </p>
            <p className="text-muted-foreground text-sm">
              or click to browse files
            </p>
          </div>
        )}
      </div>

      <Button
        size="lg"
        disabled={!file || disabled}
        onClick={() => file && onExtract(file)}
        className="w-full max-w-xs bg-primary text-primary-foreground hover:bg-primary/80 neon-border font-semibold text-base tracking-wide transition-all duration-300 hover:scale-[1.03]"
      >
        Extract Invoice Data
      </Button>
    </div>
  );
}
